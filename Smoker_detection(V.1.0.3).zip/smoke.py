from ftplib import FTP 
# import sys
# import fileinput
import time
import paho.mqtt.client as mqtt
import os
import tkinter as tk
import tkinter.font as font
from tkinter import messagebox
from tkinter import *
import cv2
from PIL import Image, ImageTk
from time import strftime
import threading
from subprocess import call

global cap
global running, flag_connected, signal_running
running = True
flag_connected = 0
signal_running = False

# face_cascade = cv2.CascadeClassifier('classifier/haarcascade_frontalcatface.xml')
# face_cascade = cv2.CascadeClassifier('classifier/haarcascade_frontalcatface_extended.xml')
# face_cascade = cv2.CascadeClassifier('classifier/cascade22stages.xml')
face_cascade = cv2.CascadeClassifier('classifier/face_detect.xml')

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        client.connected_flag = True  # set flag
        print("Connection OK")
    else:
        print("Bad connection Returned code=", rc)
        client.bad_connection_flag = True


def Time():
    global string, T
    string = strftime('%H:%M:%S %p')
    T = strftime('%d-%m-%Y_%H-%M-%S')
    lbl.config(text=string)
    lbl.after(1000, Time)


def close_vid():
    menu_frame.pack(fill='both', expand=1)
    cam_frame.forget()
    cap.release()
    global running, signal_running
    running = False
    signal_running = False
    lmain.configure(image='')


def trigger():
    global running, cap, camid, thread1, signal_running
    camid = cam_var.get()
    if camid.isnumeric():
        if int(camid) > 9 or int(camid) == 0:
            messagebox.showerror("Error", "Camera ID must be between 1-9")
            return
        else:
            l2.config(text=('Camera', camid))
            cam_frame.pack(fill='both', expand=1)
            menu_frame.forget()
    else:
        if camid.isalpha():
            messagebox.showerror("Error", "Camera ID must be an integer")
            return
        messagebox.showerror("Error", "Enter Camera ID First")
        return

    Time()
    running = True
    signal_running = True
    cap = cv2.VideoCapture(0)
    show_vid()
    thread1 = threading.Thread(target=uploadpic)
    thread1.daemon = True
    thread1.start()

def show_vid():  # creating a function
    global frame, filename, path, resize, cap, detecting

    if not cap.isOpened():  # checks for the opening of camera
        return 0
    flag, frame = cap.read()
    frame = cv2.flip(frame, 1)

    pic = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    # faces = face_cascade.detectMultiScale(gray, 1.1, 20)

    if len(faces) != 0:
        detecting = True 
    else:
        detecting = False

    path = '/home/s6301012620049/Desktop/c c++/Project/saved_images'
    filename = "cam" + camid + "_" + T + ".jpg"

    for (x, y, w, h) in faces:
        # To draw a rectangle in a face
        cv2.rectangle(pic, (x, y), (x + w, y + h), (255, 255, 0), 2)
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 255, 0), 2)
        cv2.putText(pic, 'Detected', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)
        cv2.putText(frame, 'Detected', (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36, 255, 12), 2)
        resize = cv2.resize(frame, (576, 432))

    img = Image.fromarray(pic)
    reim = img.resize((1150, 600))
    imgtk = ImageTk.PhotoImage(image=reim)
    lmain.imgtk = imgtk
    if running:
        lmain.configure(image=imgtk)
        lmain.after(10, show_vid)

def uploadpic():
    while signal_running :
        if detecting:
            print(detecting)
            cv2.imwrite(os.path.join(path, filename), resize)
            client.publish("kjpie", "cam" + camid + "_" + T)
            localfile = path+"/"+filename
            ftp = FTP()
            ftp.set_debuglevel(2)
            ftp.connect('localhost', 21) 
            ftp.login('s6301012620049','Ryu4152611')
            ftp.cwd('html/pic_upload')
            fp = open(localfile, 'rb')
            ftp.storbinary('STOR %s' % os.path.basename(localfile), fp, 1024)
            ftp.sendcmd('SITE CHMOD 644 '+filename)
            fp.close()
            time.sleep(5)
        time.sleep(1)
        
            
if __name__ == '__main__':
    broker = "localhost"
    client = mqtt.Client()
    client.on_connect = on_connect
    client.loop_start()
    print("Connecting to broker :", broker)

    try:
        client.connect(broker, 1883, 60)  # connect to broker
        flag_connected = 1
        print("Connected")
    except:
        print("Connection Failed")
        flag_connected = 0
        pass

    root = tk.Tk()
    root.title('Smoker Detection')
    root.iconphoto(True, PhotoImage(file="/home/s6301012620049/Desktop/c c++/Project/no_smoke.png"))
    root.geometry("1200x800")
    font_large = font.Font(family='Georgia', size='72', weight='bold')
    font_small = font.Font(family='Calibri', size='18')
    font_verysmall = font.Font(family='Calibri', size='12')

    # =========================================================================
    # MENU FRAME
    menu_frame = tk.Frame(root)
    menu_frame.configure(bg='#f1f1f1')

    l1 = Label(menu_frame, text="Smoker Detection", font=font_large, fg='black', bg='#f1f1f1')
    l1.place(relx=0.5, rely=0.2, anchor=CENTER)
    l3 = Label(menu_frame, text="V.1.0.2", font=font_small, fg='black', bg='#f1f1f1')
    l3.place(relx=0.95, rely=0.95, anchor=CENTER)
    l4 = Label(menu_frame, text="Server : " + broker, font=font_verysmall, fg='black', bg='#f1f1f1')
    l4.place(relx=0.07, rely=0.92, anchor=CENTER)
    l5 = Label(menu_frame, text="Topic : KJPIE", font=font_verysmall, fg='black', bg='#f1f1f1')
    l5.place(relx=0.06, rely=0.95, anchor=CENTER)
    startimg = (Image.open("start2.png"))
    resized_image = startimg.resize((300, 300), Image.ANTIALIAS)
    photoimg = ImageTk.PhotoImage(resized_image)
    b1 = Button(menu_frame, image=photoimg, borderwidth=0, bg="#f1f1f1",
                activebackground='#f1f1f1', command=trigger)
    b1.place(relx=0.5, rely=0.7, anchor=CENTER)

    le = Label(menu_frame, text="Please Input Your Camera ID", font=font.Font(family='Georgia', size='30'), fg='black',
               bg='#f1f1f1')
    le.place(relx=0.5, rely=0.4, anchor=CENTER)

    cam_var = StringVar()
    e1 = Entry(menu_frame, font=font.Font(family='Times New Roman', size='24'), textvariable=cam_var)
    e1.place(relx=0.5, rely=0.5, anchor=CENTER)

    # ==========================================================================
    # CAM FRAME
    cam_frame = tk.Frame(root)
    cam_frame.configure(bg='#f1f1f1')

    l2 = Label(cam_frame, font=font_small, fg='black', bg='#f1f1f1')
    l2.place(relx=0.06, rely=0.8, anchor=CENTER)
    l6 = Label(cam_frame, text="V.1.0.2", font=font_small, fg='black', bg='#f1f1f1')
    l6.place(relx=0.95, rely=0.95, anchor=CENTER)
    lbl = Label(cam_frame, font=font_verysmall, fg='black', bg='#f1f1f1')
    lbl.place(relx=0.06, rely=0.95, anchor=CENTER)

    b2 = Button(cam_frame, width=9, text="Stop", fg='black', bg='#EE1005', activebackground='#EE1005',
                font=font_small, borderwidth=5, command=close_vid)
    b2.place(relx=0.5, rely=0.9, anchor=CENTER)

    if flag_connected == 1:
        l7 = Label(cam_frame, text="• Connected", font=font_verysmall, fg='green', bg='#f1f1f1')
        l7.place(relx=0.945, rely=0.8, anchor=CENTER)
    elif flag_connected == 0:
        l7 = Label(cam_frame, text="• Disconnected", font=font_verysmall, fg='red', bg='#f1f1f1')
        l7.place(relx=0.945, rely=0.8, anchor=CENTER)

    lmain = tk.Label(master=cam_frame, bg='black')
    lmain.place(relx=0.5, rely=0.4, anchor=CENTER)
    # ===========================================================================
    menu_frame.pack(fill='both', expand=1)

    root.resizable(False, False)
    root.mainloop()  # keeps the application in an infinite loop so it works continuosly
    client.disconnect()
    signal_running = False
    try:
        cap.release()
    except:
        print("")